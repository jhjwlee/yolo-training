#!/usr/bin/env bash
# Bronze → staging (Spark) → silver (PostgreSQL upsert)
set -euo pipefail
source /etc/profile.d/onestore.sh; source "$LAB_HOME/config/pipeline.env"
cd "$LAB_HOME/spark" && spark-submit silver_job.py
psql -q -f "$LAB_HOME/sql/postgres/02_silver_upsert.sql"
