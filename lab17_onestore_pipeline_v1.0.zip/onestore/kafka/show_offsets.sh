#!/usr/bin/env bash
# 파티션별 끝 오프셋(= 지금까지 들어온 레코드 수)과 합계
source "$LAB_HOME/config/pipeline.env"
kafka-get-offsets.sh --bootstrap-server "$KAFKA_BOOTSTRAP" --topic "$KAFKA_TOPIC" \
  | sort | awk -F: '{print "  partition " $2 " : " $3; s += $3} END {print "  합계        : " s}'
