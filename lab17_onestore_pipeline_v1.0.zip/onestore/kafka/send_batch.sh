#!/usr/bin/env bash
# 주문 이벤트 보내기:  bash kafka/send_batch.sh 1   (또는 2)
# 파일 한 줄 = "주문번호|JSON"  → 주문번호가 Kafka 키(key)가 되어 파티션을 정한다
set -euo pipefail
source "$LAB_HOME/config/pipeline.env"
FILE="$LAB_HOME/data/batch${1:?배치 번호(1 또는 2)를 주세요}.txt"
kafka-console-producer.sh --bootstrap-server "$KAFKA_BOOTSTRAP" --topic "$KAFKA_TOPIC" \
  --property parse.key=true --property key.separator='|' < "$FILE"
echo "[kafka] $(wc -l < "$FILE")건 전송 완료: $FILE"
