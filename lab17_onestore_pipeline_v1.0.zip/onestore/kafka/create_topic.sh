#!/usr/bin/env bash
# 토픽 만들기: 파티션 3개, 복제 1 (브로커가 하나뿐)
source "$LAB_HOME/config/pipeline.env"
kafka-topics.sh --bootstrap-server "$KAFKA_BOOTSTRAP" --create --if-not-exists \
  --topic "$KAFKA_TOPIC" --partitions 3 --replication-factor 1
kafka-topics.sh --bootstrap-server "$KAFKA_BOOTSTRAP" --describe --topic "$KAFKA_TOPIC"
