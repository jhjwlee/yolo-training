#!/usr/bin/env bash
# 토픽 맨 앞의 레코드 몇 건을 키·파티션·오프셋과 함께 본다:  bash kafka/peek.sh 5
source "$LAB_HOME/config/pipeline.env"
kafka-console-consumer.sh --bootstrap-server "$KAFKA_BOOTSTRAP" --topic "$KAFKA_TOPIC" \
  --from-beginning --max-messages "${1:-5}" \
  --formatter-property print.partition=true --formatter-property print.offset=true \
  --formatter-property print.key=true --formatter-property key.separator=' | '
