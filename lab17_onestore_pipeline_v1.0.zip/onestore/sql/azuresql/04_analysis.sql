/* =====================================================================
   Gold 분석 쿼리 — 창 함수(window function)로 보는 OneStore 10월 첫째 주
   ===================================================================== */
-- Q1. 일별 매출과 전일 대비 증감
SELECT sales_date,
       SUM(revenue) AS revenue,
       SUM(revenue) - LAG(SUM(revenue)) OVER (ORDER BY sales_date) AS diff_vs_prev_day
FROM gold.daily_sales
GROUP BY sales_date
ORDER BY sales_date;

-- Q2. 날짜별 채널 비중 (%)
SELECT sales_date, channel, revenue,
       CAST(100.0 * revenue / SUM(revenue) OVER (PARTITION BY sales_date) AS DECIMAL(5, 1)) AS share_pct
FROM gold.daily_sales
ORDER BY sales_date, revenue DESC;

-- Q3. 날짜별 매출 상위 3개 상품
SELECT sales_date, rnk, product_name, revenue
FROM (SELECT sales_date, product_name, revenue,
             DENSE_RANK() OVER (PARTITION BY sales_date ORDER BY revenue DESC) AS rnk
      FROM gold.daily_product_sales) AS r
WHERE rnk <= 3
ORDER BY sales_date, rnk, product_name;

-- Q4. 카테고리별 누적 매출
SELECT category, sales_date,
       SUM(revenue) AS revenue,
       SUM(SUM(revenue)) OVER (PARTITION BY category ORDER BY sales_date
                               ROWS UNBOUNDED PRECEDING) AS running_revenue
FROM gold.daily_product_sales
GROUP BY category, sales_date
ORDER BY category, sales_date;

-- Q5. 채널별 취소율
SELECT channel,
       SUM(orders)           AS orders,
       SUM(cancelled_orders) AS cancelled_orders,
       CAST(100.0 * SUM(cancelled_orders) / SUM(orders) AS DECIMAL(5, 1)) AS cancel_rate_pct
FROM gold.daily_sales
GROUP BY channel
ORDER BY cancel_rate_pct DESC;
