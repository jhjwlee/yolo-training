/* =====================================================================
   대사(reconciliation) — Gold 숫자가 맞는지 확인
   ===================================================================== */
-- 1) 날짜별 Gold 합계 → VM의 psql 결과(sql/postgres/04_reconcile.sql)와 같아야 한다
SELECT sales_date,
       SUM(orders)           AS orders,
       SUM(cancelled_orders) AS cancelled_orders,
       SUM(items)            AS items,
       SUM(revenue)          AS revenue
FROM gold.daily_sales
GROUP BY sales_date
ORDER BY sales_date;

-- 2) 두 Gold 테이블끼리도 맞아야 한다 (채널로 묶든 상품으로 묶든 합계는 같다)
SELECT d.sales_date, d.revenue AS by_channel, p.revenue AS by_product,
       CASE WHEN d.revenue = p.revenue THEN 'OK' ELSE 'MISMATCH' END AS check_result
FROM (SELECT sales_date, SUM(revenue) AS revenue FROM gold.daily_sales GROUP BY sales_date) AS d
JOIN (SELECT sales_date, SUM(revenue) AS revenue FROM gold.daily_product_sales GROUP BY sales_date) AS p
  ON p.sales_date = d.sales_date
ORDER BY d.sales_date;

-- 3) 적재 기록
SELECT TOP (10) * FROM gold.load_log ORDER BY load_id DESC;
