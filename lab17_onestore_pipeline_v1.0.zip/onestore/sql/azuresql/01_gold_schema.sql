/* =====================================================================
   OneStore Gold 스키마 (Azure SQL Database)
   SSMS에서 onestore_gold 데이터베이스를 선택하고 실행 (여러 번 실행해도 됨)
   ===================================================================== */
IF SCHEMA_ID('gold') IS NULL EXEC('CREATE SCHEMA gold');
GO

-- 1) Gold 본 테이블 — KST 날짜 기준 집계. 취소된 주문은 orders에 포함, items·revenue에서는 제외
IF OBJECT_ID('gold.daily_sales') IS NULL
CREATE TABLE gold.daily_sales (
    sales_date       DATE         NOT NULL,
    channel          VARCHAR(10)  NOT NULL,
    orders           INT          NOT NULL,
    cancelled_orders INT          NOT NULL,
    items            INT          NOT NULL,
    revenue          BIGINT       NOT NULL,
    updated_at       DATETIME2(0) NOT NULL CONSTRAINT DF_daily_sales_updated DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_daily_sales PRIMARY KEY (sales_date, channel)
);

IF OBJECT_ID('gold.daily_product_sales') IS NULL
CREATE TABLE gold.daily_product_sales (
    sales_date       DATE          NOT NULL,
    product_id       VARCHAR(10)   NOT NULL,
    product_name     NVARCHAR(50)  NOT NULL,
    category         VARCHAR(20)   NOT NULL,
    orders           INT           NOT NULL,
    cancelled_orders INT           NOT NULL,
    items            INT           NOT NULL,
    revenue          BIGINT        NOT NULL,
    updated_at       DATETIME2(0)  NOT NULL CONSTRAINT DF_daily_product_updated DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_daily_product_sales PRIMARY KEY (sales_date, product_id)
);

-- 2) staging — Spark gold_job이 매번 비우고 채운다
IF OBJECT_ID('gold.stg_daily_sales') IS NULL
CREATE TABLE gold.stg_daily_sales (
    sales_date DATE, channel VARCHAR(10), orders INT, cancelled_orders INT, items INT, revenue BIGINT
);
IF OBJECT_ID('gold.stg_daily_product_sales') IS NULL
CREATE TABLE gold.stg_daily_product_sales (
    sales_date DATE, product_id VARCHAR(10), product_name NVARCHAR(50), category VARCHAR(20),
    orders INT, cancelled_orders INT, items INT, revenue BIGINT
);
IF OBJECT_ID('gold.stg_run') IS NULL
CREATE TABLE gold.stg_run (from_date DATE, to_date DATE, lookback_days INT);

-- 3) 적재 기록
IF OBJECT_ID('gold.load_log') IS NULL
CREATE TABLE gold.load_log (
    load_id      INT IDENTITY PRIMARY KEY,
    loaded_at    DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME(),
    from_date    DATE NOT NULL,
    to_date      DATE NOT NULL,
    rows_staged  INT  NOT NULL,
    rows_inserted INT NOT NULL,
    rows_updated INT  NOT NULL
);
GO

SELECT s.name AS schema_name, t.name AS table_name
FROM sys.tables AS t JOIN sys.schemas AS s ON s.schema_id = t.schema_id
WHERE s.name = 'gold' ORDER BY t.name;       -- 6개
