/* =====================================================================
   staging → Gold 반영 프로시저
   - 재계산 범위의 값을 MERGE로 덮어쓴다 (같은 값이면 건드리지 않는다 → 다시 실행해도 결과가 같다)
   - WHEN NOT MATCHED BY SOURCE THEN DELETE는 쓰지 않는다: staging에는 최근 며칠만 있으므로
     이 절을 넣으면 재계산 범위 밖의 과거 Gold가 전부 지워진다
   ===================================================================== */
CREATE OR ALTER PROCEDURE gold.usp_merge_gold
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @from DATE, @to DATE;
    SELECT @from = from_date, @to = to_date FROM gold.stg_run;
    IF @from IS NULL
        THROW 50001, N'gold.stg_run이 비어 있습니다. VM에서 run_gold.sh를 먼저 실행하세요.', 1;

    DECLARE @act TABLE (tbl VARCHAR(30), action NVARCHAR(10));

    BEGIN TRAN;

    MERGE gold.daily_sales AS t
    USING gold.stg_daily_sales AS s
       ON t.sales_date = s.sales_date AND t.channel = s.channel
    WHEN MATCHED AND (t.orders <> s.orders OR t.cancelled_orders <> s.cancelled_orders
                      OR t.items <> s.items OR t.revenue <> s.revenue) THEN
        UPDATE SET orders = s.orders, cancelled_orders = s.cancelled_orders,
                   items = s.items, revenue = s.revenue, updated_at = SYSUTCDATETIME()
    WHEN NOT MATCHED BY TARGET THEN
        INSERT (sales_date, channel, orders, cancelled_orders, items, revenue)
        VALUES (s.sales_date, s.channel, s.orders, s.cancelled_orders, s.items, s.revenue)
    OUTPUT 'daily_sales', $action INTO @act;

    MERGE gold.daily_product_sales AS t
    USING gold.stg_daily_product_sales AS s
       ON t.sales_date = s.sales_date AND t.product_id = s.product_id
    WHEN MATCHED AND (t.orders <> s.orders OR t.cancelled_orders <> s.cancelled_orders
                      OR t.items <> s.items OR t.revenue <> s.revenue) THEN
        UPDATE SET product_name = s.product_name, category = s.category, orders = s.orders,
                   cancelled_orders = s.cancelled_orders, items = s.items, revenue = s.revenue,
                   updated_at = SYSUTCDATETIME()
    WHEN NOT MATCHED BY TARGET THEN
        INSERT (sales_date, product_id, product_name, category, orders, cancelled_orders, items, revenue)
        VALUES (s.sales_date, s.product_id, s.product_name, s.category, s.orders, s.cancelled_orders, s.items, s.revenue)
    OUTPUT 'daily_product_sales', $action INTO @act;

    INSERT gold.load_log (from_date, to_date, rows_staged, rows_inserted, rows_updated)
    SELECT @from, @to,
           (SELECT COUNT(*) FROM gold.stg_daily_sales) + (SELECT COUNT(*) FROM gold.stg_daily_product_sales),
           (SELECT COUNT(*) FROM @act WHERE action = 'INSERT'),
           (SELECT COUNT(*) FROM @act WHERE action = 'UPDATE');

    COMMIT;

    -- 결과 요약: 재계산 범위와 테이블별 INSERT / UPDATE 건수
    SELECT @from AS from_date, @to AS to_date, tbl,
           SUM(CASE WHEN action = 'INSERT' THEN 1 ELSE 0 END) AS inserted,
           SUM(CASE WHEN action = 'UPDATE' THEN 1 ELSE 0 END) AS updated
    FROM (SELECT tbl, action FROM @act
          UNION ALL SELECT 'daily_sales', NULL
          UNION ALL SELECT 'daily_product_sales', NULL) AS a
    GROUP BY tbl
    ORDER BY tbl DESC;
END;
GO
