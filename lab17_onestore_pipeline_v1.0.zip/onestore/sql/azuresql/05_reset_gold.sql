/* 실습을 처음부터 다시 할 때 — Gold 데이터만 비운다 (테이블·프로시저는 남긴다) */
TRUNCATE TABLE gold.daily_sales;
TRUNCATE TABLE gold.daily_product_sales;
TRUNCATE TABLE gold.stg_daily_sales;
TRUNCATE TABLE gold.stg_daily_product_sales;
TRUNCATE TABLE gold.stg_run;
TRUNCATE TABLE gold.load_log;
