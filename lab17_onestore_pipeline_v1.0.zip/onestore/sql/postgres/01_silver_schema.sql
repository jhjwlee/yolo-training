-- =====================================================================
-- OneStore Silver 스키마 (PostgreSQL 16)
-- 품질은 코드가 아니라 스키마가 지킨다: PK · FK · CHECK
-- 실행: psql -f sql/postgres/01_silver_schema.sql   (여러 번 실행해도 됨)
-- =====================================================================
CREATE SCHEMA IF NOT EXISTS silver;

-- 1) 기준 데이터 (상품·고객)
CREATE TABLE IF NOT EXISTS silver.products (
    product_id   VARCHAR(10) PRIMARY KEY,
    product_name VARCHAR(50) NOT NULL,
    category     VARCHAR(20) NOT NULL,
    list_price   INT         NOT NULL CHECK (list_price > 0)
);
CREATE TABLE IF NOT EXISTS silver.customers (
    customer_id VARCHAR(10) PRIMARY KEY,
    city        VARCHAR(20) NOT NULL,
    grade       VARCHAR(10) NOT NULL CHECK (grade IN ('BRONZE', 'SILVER', 'GOLD'))
);
INSERT INTO silver.products VALUES
 ('P001', '무선 이어폰', 'electronics', 89000), ('P002', '보조배터리 10000mAh', 'electronics', 32000),
 ('P003', 'USB-C 충전기 65W', 'electronics', 45000), ('P004', '텀블러 500ml', 'living', 18000),
 ('P005', '캠핑 의자', 'living', 54000), ('P006', '드립 커피 세트', 'food', 27000),
 ('P007', '그래놀라 1kg', 'food', 15000), ('P008', '러닝 양말 3팩', 'fashion', 12000)
ON CONFLICT (product_id) DO NOTHING;
INSERT INTO silver.customers
SELECT 'C' || lpad(i::text, 3, '0'),
       (ARRAY['서울', '부산', '대구', '인천', '대전'])[1 + i % 5],
       (ARRAY['BRONZE', 'SILVER', 'GOLD'])[1 + i % 3]
FROM generate_series(1, 20) AS g(i)
ON CONFLICT (customer_id) DO NOTHING;

-- 2) 주문 (Silver 본 테이블) — 시각은 TIMESTAMPTZ(절대 시각)로 저장
CREATE TABLE IF NOT EXISTS silver.orders (
    order_id      VARCHAR(20) PRIMARY KEY,
    customer_id   VARCHAR(10) NOT NULL REFERENCES silver.customers,
    product_id    VARCHAR(10) NOT NULL REFERENCES silver.products,
    qty           INT         NOT NULL CHECK (qty > 0),
    unit_price    INT         NOT NULL CHECK (unit_price > 0),
    amount        BIGINT      GENERATED ALWAYS AS (qty::bigint * unit_price) STORED,
    channel       VARCHAR(10) NOT NULL CHECK (channel IN ('app', 'web', 'store')),
    status        VARCHAR(10) NOT NULL DEFAULT 'PLACED' CHECK (status IN ('PLACED', 'CANCELLED')),
    ordered_at    TIMESTAMPTZ NOT NULL,
    cancelled_at  TIMESTAMPTZ,
    src_event_id  VARCHAR(20) NOT NULL,
    src_partition INT         NOT NULL,
    src_offset    BIGINT      NOT NULL,
    loaded_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_orders_ordered_at ON silver.orders (ordered_at);

-- 3) 거부된 레코드 — 사유 · 원문 · Kafka 좌표를 함께 남긴다 (같은 레코드는 한 번만)
CREATE TABLE IF NOT EXISTS silver.rejected (
    src_topic     VARCHAR(100) NOT NULL,
    src_partition INT          NOT NULL,
    src_offset    BIGINT       NOT NULL,
    reject_reason VARCHAR(30)  NOT NULL,
    raw_value     TEXT,
    kafka_ts      TIMESTAMPTZ,
    rejected_at   TIMESTAMPTZ  NOT NULL DEFAULT now(),
    PRIMARY KEY (src_topic, src_partition, src_offset)
);

-- 4) staging — Spark가 매번 비우고 채운다. 시각은 TIMESTAMP(시간대 없음, 값은 UTC)
CREATE TABLE IF NOT EXISTS silver.stg_order_placed (
    event_id VARCHAR(20), order_id VARCHAR(20), customer_id VARCHAR(10), product_id VARCHAR(10),
    qty INT, unit_price INT, channel VARCHAR(10), event_ts TIMESTAMP,
    src_partition INT, src_offset BIGINT
);
CREATE TABLE IF NOT EXISTS silver.stg_order_cancelled (
    event_id VARCHAR(20), order_id VARCHAR(20), event_ts TIMESTAMP, raw_value TEXT,
    src_topic VARCHAR(100), src_partition INT, src_offset BIGINT
);
CREATE TABLE IF NOT EXISTS silver.stg_rejected (
    reject_reason VARCHAR(30), raw_value TEXT, src_topic VARCHAR(100),
    src_partition INT, src_offset BIGINT, kafka_ts TIMESTAMP
);

SELECT 'products' AS tbl, count(*) FROM silver.products
UNION ALL SELECT 'customers', count(*) FROM silver.customers;   -- 8, 20
