-- =====================================================================
-- 대사(reconciliation) — Silver 기준 날짜별 합계. Azure SQL의 03_reconcile.sql 1번과 같아야 한다
-- =====================================================================
SELECT (ordered_at AT TIME ZONE 'Asia/Seoul')::date                  AS sales_date,
       count(*)                                                      AS orders,
       count(*) FILTER (WHERE status = 'CANCELLED')                  AS cancelled_orders,
       coalesce(sum(qty)    FILTER (WHERE status <> 'CANCELLED'), 0) AS items,
       coalesce(sum(amount) FILTER (WHERE status <> 'CANCELLED'), 0) AS revenue
FROM silver.orders
GROUP BY 1
ORDER BY 1;
