-- =====================================================================
-- staging → silver 반영 (멱등: 몇 번을 실행해도 결과가 같다)
-- staging의 event_ts는 TIMESTAMP(시간대 없음)이고 값은 UTC → AT TIME ZONE 'UTC'로 절대 시각으로 바꾼다
-- =====================================================================
\set ON_ERROR_STOP on
BEGIN;

-- 1) 주문 생성: 이미 있는 주문은 건드리지 않는다
WITH ins AS (
    INSERT INTO silver.orders (order_id, customer_id, product_id, qty, unit_price, channel,
                               ordered_at, src_event_id, src_partition, src_offset)
    SELECT order_id, customer_id, product_id, qty, unit_price, channel,
           event_ts AT TIME ZONE 'UTC', event_id, src_partition, src_offset
    FROM silver.stg_order_placed
    ON CONFLICT (order_id) DO NOTHING
    RETURNING 1)
SELECT 'orders_inserted' AS step, count(*) AS rows FROM ins;

-- 2) 취소: 없는 주문에 대한 취소는 거부 테이블로
WITH rej AS (
    INSERT INTO silver.rejected (src_topic, src_partition, src_offset, reject_reason, raw_value)
    SELECT c.src_topic, c.src_partition, c.src_offset, 'CANCEL_UNKNOWN_ORDER', c.raw_value
    FROM silver.stg_order_cancelled AS c
    WHERE NOT EXISTS (SELECT 1 FROM silver.orders AS o WHERE o.order_id = c.order_id)
    ON CONFLICT DO NOTHING
    RETURNING 1)
SELECT 'cancel_rejected' AS step, count(*) AS rows FROM rej;

WITH upd AS (
    UPDATE silver.orders AS o
    SET status = 'CANCELLED', cancelled_at = c.event_ts AT TIME ZONE 'UTC', updated_at = now()
    FROM silver.stg_order_cancelled AS c
    WHERE o.order_id = c.order_id AND o.status <> 'CANCELLED'
    RETURNING 1)
SELECT 'orders_cancelled' AS step, count(*) AS rows FROM upd;

-- 3) Spark가 거부한 레코드
WITH rej AS (
    INSERT INTO silver.rejected (src_topic, src_partition, src_offset, reject_reason, raw_value, kafka_ts)
    SELECT src_topic, src_partition, src_offset, reject_reason, raw_value, kafka_ts AT TIME ZONE 'UTC'
    FROM silver.stg_rejected
    ON CONFLICT DO NOTHING
    RETURNING 1)
SELECT 'rejected_inserted' AS step, count(*) AS rows FROM rej;

COMMIT;
