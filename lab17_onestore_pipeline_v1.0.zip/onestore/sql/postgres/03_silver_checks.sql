-- =====================================================================
-- Silver 확인 쿼리
-- =====================================================================
-- 1) 주문 상태별 건수
SELECT status, count(*) AS orders, sum(amount) AS amount
FROM silver.orders GROUP BY status ORDER BY status;

-- 2) 거부 사유별 건수
SELECT reject_reason, count(*) AS records
FROM silver.rejected GROUP BY reject_reason ORDER BY reject_reason;

-- 3) 같은 주문을 UTC 날짜와 KST 날짜로 묶으면? (세션 시간대와 무관하게 명시적으로 변환)
SELECT (ordered_at AT TIME ZONE 'UTC')::date        AS utc_date,
       (ordered_at AT TIME ZONE 'Asia/Seoul')::date AS kst_date,
       count(*) AS orders
FROM silver.orders
GROUP BY 1, 2 ORDER BY 1, 2;

-- 4) 자정 근처 주문 — 저장 값(UTC)과 표시 값(KST)
SELECT order_id,
       ordered_at AT TIME ZONE 'UTC'        AS utc_time,
       ordered_at AT TIME ZONE 'Asia/Seoul' AS kst_time
FROM silver.orders
WHERE (ordered_at AT TIME ZONE 'Asia/Seoul')::time NOT BETWEEN '00:20' AND '23:45'
ORDER BY ordered_at;

-- 5) staging의 TIMESTAMP(시간대 없음, 값은 UTC)를 그냥 캐스팅하면? — 세션 시간대(Asia/Seoul)로 해석되어 9시간 어긋난다
SELECT order_id,
       event_ts                                                 AS staging_value,
       event_ts::timestamptz                                    AS implicit_cast,   -- 틀림
       event_ts AT TIME ZONE 'UTC'                              AS explicit_utc,    -- 맞음
       (event_ts::timestamptz AT TIME ZONE 'Asia/Seoul')::date  AS wrong_kst_date,
       ((event_ts AT TIME ZONE 'UTC') AT TIME ZONE 'Asia/Seoul')::date AS right_kst_date
FROM silver.stg_order_placed
WHERE order_id = 'O-1304';
