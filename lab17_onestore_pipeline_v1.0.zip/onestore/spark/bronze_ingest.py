"""Bronze: Kafka 토픽의 레코드를 해석하지 않고 그대로 Parquet에 보관한다.

- trigger(availableNow=True): 지금까지 쌓인 레코드를 모두 읽고 스스로 멈춘다 (배치처럼 실행하는 스트리밍)
- checkpointLocation: 어디까지 읽었는지(오프셋)를 기록 → 다시 실행해도 같은 레코드를 두 번 쓰지 않는다
"""
from pyspark.sql import SparkSession, functions as F
import common as C

spark = SparkSession.builder.appName("onestore-bronze").getOrCreate()

source = (spark.readStream.format("kafka")
          .option("kafka.bootstrap.servers", C.KAFKA_BOOTSTRAP)
          .option("subscribe", C.KAFKA_TOPIC)
          .option("startingOffsets", "earliest")      # 체크포인트가 없을 때(첫 실행)만 쓰인다
          .load())

bronze = (source.select(
            F.col("key").cast("string").alias("kafka_key"),
            F.col("value").cast("string").alias("raw_value"),   # 원문 JSON을 문자열 그대로
            F.col("topic"), F.col("partition"), F.col("offset"),  # Kafka 좌표 = 계보(lineage)
            F.col("timestamp").alias("kafka_ts"),
            F.current_timestamp().alias("ingested_at"))
          .withColumn("ingest_date", F.to_date("kafka_ts")))

query = (bronze.writeStream.format("parquet")
         .option("path", C.BRONZE_PATH)
         .option("checkpointLocation", C.BRONZE_CHECKPOINT)
         .partitionBy("ingest_date")
         .trigger(availableNow=True)
         .start())
query.awaitTermination()

rows = sum(p["numInputRows"] for p in query.recentProgress)
print(f"[bronze] 이번 실행에서 Kafka로부터 읽은 레코드: {rows}건 → {C.BRONZE_PATH}")
spark.stop()
