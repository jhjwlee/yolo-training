"""Silver: Bronze 원문을 해석·검증·중복 제거해 PostgreSQL staging 테이블에 적재한다.

이후 sql/postgres/02_silver_upsert.sql이 staging → silver 본 테이블로 멱등(idempotent)하게 반영한다.
"""
from pyspark.sql import SparkSession, DataFrame, Window, functions as F, types as T
import common as C

EVENT_SCHEMA = T.StructType([
    T.StructField("event_id", T.StringType()),
    T.StructField("event_type", T.StringType()),
    T.StructField("order_id", T.StringType()),
    T.StructField("customer_id", T.StringType()),
    T.StructField("product_id", T.StringType()),
    T.StructField("qty", T.LongType()),
    T.StructField("unit_price", T.LongType()),
    T.StructField("channel", T.StringType()),
    T.StructField("event_ts", T.StringType()),
    T.StructField("_corrupt", T.StringType()),       # 해석에 실패한 원문이 들어오는 칸
])
CHANNELS = ["app", "web", "store"]


def classify(bronze: DataFrame, products: DataFrame, customers: DataFrame):
    """Bronze → (주문 생성, 주문 취소, 거부, 중복 수) 로 나눈다."""
    j = F.from_json("raw_value", EVENT_SCHEMA,
                    {"mode": "PERMISSIVE", "columnNameOfCorruptRecord": "_corrupt"})
    ev = (bronze.select("raw_value", "topic", "partition", "offset", "kafka_ts", j.alias("j"))
          .select("raw_value", "topic", "partition", "offset", "kafka_ts", "j.*")
          .withColumn("ts", F.to_timestamp("event_ts"))         # 형식이 틀리면 NULL (ANSI 모드 꺼짐)
          .join(products.select(F.col("product_id").alias("p_ok")), F.col("product_id") == F.col("p_ok"), "left")
          .join(customers.select(F.col("customer_id").alias("c_ok")), F.col("customer_id") == F.col("c_ok"), "left"))

    placed = F.col("event_type") == "ORDER_PLACED"
    missing = (F.col("event_id").isNull() | F.col("order_id").isNull() | F.col("event_ts").isNull()
               | (placed & (F.col("customer_id").isNull() | F.col("product_id").isNull() | F.col("qty").isNull()
                            | F.col("unit_price").isNull() | F.col("channel").isNull())))
    reason = (F.when(F.col("_corrupt").isNotNull(), "BAD_JSON")
               .when(F.col("event_type").isNull(), "MISSING_FIELD")
               .when(~F.col("event_type").isin("ORDER_PLACED", "ORDER_CANCELLED"), "UNKNOWN_EVENT_TYPE")
               .when(missing, "MISSING_FIELD")
               .when(F.col("ts").isNull(), "BAD_TIMESTAMP")
               .when(placed & (F.col("qty") <= 0), "INVALID_QTY")
               .when(placed & (F.col("unit_price") <= 0), "INVALID_PRICE")
               .when(placed & ~F.col("channel").isin(*CHANNELS), "INVALID_CHANNEL")
               .when(placed & F.col("p_ok").isNull(), "UNKNOWN_PRODUCT")
               .when(placed & F.col("c_ok").isNull(), "UNKNOWN_CUSTOMER"))
    ev = ev.withColumn("reject_reason", reason)

    rejected = (ev.filter(F.col("reject_reason").isNotNull())
                  .select("reject_reason", "raw_value", F.col("topic").alias("src_topic"),
                          F.col("partition").alias("src_partition"), F.col("offset").alias("src_offset"),
                          F.col("kafka_ts")))

    good = ev.filter(F.col("reject_reason").isNull())
    # 같은 event_id가 여러 번 들어오면(생산자 재전송) 가장 먼저 들어온 것 하나만 남긴다
    w = Window.partitionBy("event_id").orderBy("partition", "offset")
    dedup = good.withColumn("rn", F.row_number().over(w)).filter("rn = 1").drop("rn")

    out_placed = (dedup.filter(placed)
                  .select("event_id", "order_id", "customer_id", "product_id",
                          F.col("qty").cast("int").alias("qty"), F.col("unit_price").cast("int").alias("unit_price"),
                          "channel", F.col("ts").alias("event_ts"),
                          F.col("partition").alias("src_partition"), F.col("offset").alias("src_offset")))
    out_cancel = (dedup.filter(F.col("event_type") == "ORDER_CANCELLED")
                  .select("event_id", "order_id", F.col("ts").alias("event_ts"), "raw_value",
                          F.col("topic").alias("src_topic"), F.col("partition").alias("src_partition"),
                          F.col("offset").alias("src_offset")))
    return out_placed, out_cancel, rejected, good, dedup


def main():
    spark = SparkSession.builder.appName("onestore-silver").getOrCreate()
    bronze = spark.read.parquet(C.BRONZE_PATH)
    products = spark.read.format("jdbc").options(**C.pg_options(table="silver.products")).load()
    customers = spark.read.format("jdbc").options(**C.pg_options(table="silver.customers")).load()

    placed, cancel, rejected, good, dedup = classify(bronze, products, customers)
    for df in (placed, cancel, rejected):
        df.cache()

    # staging은 매번 비우고 다시 채운다 (truncate=true → 테이블 정의는 그대로 둔다)
    for df, table in ((placed, "silver.stg_order_placed"), (cancel, "silver.stg_order_cancelled"),
                      (rejected, "silver.stg_rejected")):
        (df.write.format("jdbc").options(**C.pg_options(table=table))
           .option("truncate", "true").mode("overwrite").save())

    n_bronze, n_good, n_dedup = bronze.count(), good.count(), dedup.count()
    print(f"[silver] Bronze 레코드 {n_bronze}건 = 주문 생성 {placed.count()} + 주문 취소 {cancel.count()}"
          f" + 거부 {rejected.count()} + 중복 제거 {n_good - n_dedup}")
    rejected.groupBy("reject_reason").count().orderBy("reject_reason").show(truncate=False)
    spark.stop()


if __name__ == "__main__":
    main()
