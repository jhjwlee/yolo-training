"""OneStore 파이프라인 공통 설정 — 접속 정보는 config/pipeline.env에서 환경 변수로 받는다."""
import os

KAFKA_BOOTSTRAP = os.environ.get("KAFKA_BOOTSTRAP", "localhost:9092")
KAFKA_TOPIC = os.environ.get("KAFKA_TOPIC", "onestore.orders")
DATA_DIR = os.environ.get("DATA_DIR", "/data")
BRONZE_PATH = f"{DATA_DIR}/bronze/orders"
BRONZE_CHECKPOINT = f"{DATA_DIR}/checkpoints/bronze_orders"


def pg_options(table=None, query=None):
    """PostgreSQL(Silver) JDBC 옵션"""
    o = {
        "url": f"jdbc:postgresql://{os.environ.get('PGHOST', 'localhost')}:{os.environ.get('PGPORT', '5432')}/{os.environ['PGDATABASE']}",
        "user": os.environ["PGUSER"],
        "password": os.environ["PGPASSWORD"],
        "driver": "org.postgresql.Driver",
    }
    if table:
        o["dbtable"] = table
    if query:
        o["query"] = query
    return o


def sql_options(table):
    """Azure SQL Database(Gold) JDBC 옵션"""
    server = os.environ["SQL_SERVER"]            # 예: onestore-sql-jhl.database.windows.net
    return {
        "url": (f"jdbc:sqlserver://{server}:1433;database={os.environ['SQL_DB']};"
                "encrypt=true;trustServerCertificate=false;"
                "hostNameInCertificate=*.database.windows.net;loginTimeout=60;"),
        "user": os.environ["SQL_USER"],
        "password": os.environ["SQL_PASSWORD"],
        "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver",
        "dbtable": table,
    }
