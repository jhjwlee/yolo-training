"""Gold: Silver 주문을 KST 날짜 기준으로 다시 집계(재계산)해 Azure SQL staging 테이블에 적재한다.

- 최근 GOLD_LOOKBACK_DAYS일(기본 3일)을 통째로 다시 계산한다 → 지연 도착·취소가 반영된다
- 실제 반영(MERGE)은 Azure SQL의 gold.usp_merge_gold 프로시저가 한다
"""
import datetime as dt
import os
from pyspark.sql import SparkSession, DataFrame, functions as F
import common as C

KST = "Asia/Seoul"


def aggregate(orders: DataFrame, products: DataFrame, d_from: dt.date, d_to: dt.date):
    """orders: silver.orders (ordered_at = UTC 시각) → 일별·채널별, 일별·상품별 집계"""
    o = (orders.withColumn("sales_date", F.to_date(F.from_utc_timestamp("ordered_at", KST)))  # 시간대 변환은 여기 한 곳
               .filter(F.col("sales_date").between(F.lit(d_from), F.lit(d_to)))
               .withColumn("is_cx", (F.col("status") == "CANCELLED").cast("int"))
               .withColumn("net_qty", F.when(F.col("is_cx") == 0, F.col("qty")).otherwise(0))
               .withColumn("net_amt", F.when(F.col("is_cx") == 0, F.col("qty") * F.col("unit_price")).otherwise(0)))
    metrics = [F.count("*").cast("int").alias("orders"), F.sum("is_cx").cast("int").alias("cancelled_orders"),
               F.sum("net_qty").cast("int").alias("items"), F.sum("net_amt").cast("long").alias("revenue")]
    daily = o.groupBy("sales_date", "channel").agg(*metrics)
    product = (o.groupBy("sales_date", "product_id").agg(*metrics)
                .join(products.select("product_id", "product_name", "category"), "product_id")
                .select("sales_date", "product_id", "product_name", "category",
                        "orders", "cancelled_orders", "items", "revenue"))
    return daily, product


def main():
    spark = SparkSession.builder.appName("onestore-gold").getOrCreate()
    lookback = int(os.environ.get("GOLD_LOOKBACK_DAYS", "3"))

    # 기준일 = Silver에 있는 가장 최근 주문 날짜(KST). 실습 데이터가 과거 날짜라서 오늘 날짜를 쓰지 않는다
    last = (spark.read.format("jdbc")
            .options(**C.pg_options(query="SELECT max((ordered_at AT TIME ZONE 'Asia/Seoul')::date) AS d FROM silver.orders"))
            .load().first()["d"])
    d_to = dt.date.fromisoformat(os.environ["GOLD_TO_DATE"]) if os.environ.get("GOLD_TO_DATE") else last
    d_from = d_to - dt.timedelta(days=lookback - 1)

    # 범위보다 하루씩 넓게 읽고(UTC/KST 경계), 정확한 범위는 aggregate()에서 KST 날짜로 자른다
    q = (f"SELECT order_id, product_id, channel, qty, unit_price, status, ordered_at FROM silver.orders "
         f"WHERE ordered_at >= DATE '{d_from - dt.timedelta(days=1)}' AND ordered_at < DATE '{d_to + dt.timedelta(days=2)}'")
    orders = spark.read.format("jdbc").options(**C.pg_options(query=q)).load()
    products = spark.read.format("jdbc").options(**C.pg_options(table="silver.products")).load()

    daily, product = aggregate(orders, products, d_from, d_to)
    run = spark.createDataFrame([(d_from, d_to, lookback)], "from_date date, to_date date, lookback_days int")

    for df, table in ((daily, "gold.stg_daily_sales"), (product, "gold.stg_daily_product_sales"), (run, "gold.stg_run")):
        df.write.format("jdbc").options(**C.sql_options(table)).option("truncate", "true").mode("overwrite").save()

    print(f"[gold] 재계산 범위 {d_from} ~ {d_to} (KST, {lookback}일) → staging 적재: "
          f"일별 {daily.count()}행, 상품별 {product.count()}행")
    print("[gold] 다음 단계: SSMS에서  EXEC gold.usp_merge_gold;")
    spark.stop()


if __name__ == "__main__":
    main()
