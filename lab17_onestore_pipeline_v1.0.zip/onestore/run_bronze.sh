#!/usr/bin/env bash
# Kafka → Bronze (Parquet)
set -euo pipefail
source /etc/profile.d/onestore.sh; source "$LAB_HOME/config/pipeline.env"
cd "$LAB_HOME/spark" && spark-submit bronze_ingest.py
