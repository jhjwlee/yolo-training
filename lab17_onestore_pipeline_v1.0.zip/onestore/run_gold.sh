#!/usr/bin/env bash
# silver → Gold staging (Spark → Azure SQL). 반영은 SSMS에서 EXEC gold.usp_merge_gold
set -euo pipefail
source /etc/profile.d/onestore.sh; source "$LAB_HOME/config/pipeline.env"
cd "$LAB_HOME/spark" && spark-submit gold_job.py
