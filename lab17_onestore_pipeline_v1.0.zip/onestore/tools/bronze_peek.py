"""Bronze 들여다보기:  spark-submit tools/bronze_peek.py"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "spark"))
from pyspark.sql import SparkSession, functions as F
import common as C

spark = SparkSession.builder.appName("bronze-peek").getOrCreate()
df = spark.read.parquet(C.BRONZE_PATH)
print(f"[bronze] 전체 {df.count()}건")
df.groupBy("partition").agg(F.count("*").alias("records"), F.min("offset").alias("min_offset"),
                            F.max("offset").alias("max_offset")).orderBy("partition").show()
df.select("partition", "offset", "kafka_key", F.substring("raw_value", 1, 60).alias("raw_value_60"))\
  .orderBy("partition", "offset").show(3, truncate=False)
spark.stop()
