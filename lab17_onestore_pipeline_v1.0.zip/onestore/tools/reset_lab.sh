#!/usr/bin/env bash
# 실습을 처음부터 다시 할 때: Kafka 토픽 · Bronze · 체크포인트 · Silver 데이터를 지운다
# (Gold는 SSMS에서 sql/azuresql/05_reset_gold.sql 실행)
set -euo pipefail
source /etc/profile.d/onestore.sh; source "$LAB_HOME/config/pipeline.env"
read -r -p "Kafka 토픽, Bronze, Silver 데이터를 모두 지웁니다. 계속할까요? (yes 입력) " ans
[ "$ans" = "yes" ] || { echo "취소했습니다."; exit 0; }
kafka-topics.sh --bootstrap-server "$KAFKA_BOOTSTRAP" --delete --topic "$KAFKA_TOPIC" 2>/dev/null || true
rm -rf "$DATA_DIR/bronze/orders" "$DATA_DIR/checkpoints/bronze_orders"
psql -q -c "TRUNCATE silver.orders, silver.rejected, silver.stg_order_placed, silver.stg_order_cancelled, silver.stg_rejected;"
echo "[reset] 완료 — 2부(토픽 만들기)부터 다시 시작하세요."
