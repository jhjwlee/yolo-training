# spark.jars.packages에 적힌 JDBC 드라이버·Kafka 커넥터를 미리 내려받기 위한 빈 작업
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName("warmup").getOrCreate()
print("[warmup] Spark", spark.version, "— packages ready")
spark.stop()
