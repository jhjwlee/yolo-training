# OneStore 데이터 파이프라인 실습 자료

Kafka → Spark → PostgreSQL(Silver) → Azure SQL Database(Gold) 로 이어지는
주문 데이터 분석 프로젝트 실습 자료입니다. 실습서(51_lab17)를 따라 진행합니다.

## 폴더 구성

| 경로 | 내용 |
|------|------|
| `setup/setup_vm.sh` | VM 설치 스크립트 (Java 17, Spark 3.5.9, Kafka 4.3.1, PostgreSQL 16) |
| `setup/check_env.sh` | 설치 확인 |
| `config/pipeline.env.example` | 접속 정보 견본 — 설치 때 `pipeline.env`로 복사됨 |
| `data/batch1.txt`, `data/batch2.txt` | 주문 이벤트 (한 줄 = `주문번호\|JSON`) |
| `kafka/*.sh` | 토픽 만들기 · 보내기 · 들여다보기 · 오프셋 확인 |
| `spark/*.py` | Bronze · Silver · Gold 작업 |
| `sql/postgres/*.sql` | Silver 스키마 · upsert · 확인 · 대사 |
| `sql/azuresql/*.sql` | Gold 스키마 · MERGE 프로시저 · 대사 · 분석 · 초기화 |
| `run_bronze.sh` `run_silver.sh` `run_gold.sh` `run_pipeline.sh` | 실행 스크립트 |
| `tools/` | 드라이버 미리 받기, Bronze 들여다보기, 실습 초기화 |

## 빠른 순서

```bash
python3 -m zipfile -e lab17_onestore_pipeline_v1.0.zip ~   # ~/onestore 생성
bash ~/onestore/setup/setup_vm.sh
source ~/.bashrc
nano ~/onestore/config/pipeline.env                        # SQL_SERVER, SQL_PASSWORD 입력
bash ~/onestore/setup/check_env.sh
```

스크립트는 `bash 파일이름`으로 실행합니다 (zip을 풀면 실행 권한이 빠질 수 있음).
