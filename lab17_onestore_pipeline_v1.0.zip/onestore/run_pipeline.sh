#!/usr/bin/env bash
# 세 단계를 순서대로 — 앞 단계가 실패하면 멈춘다 (set -e)
set -euo pipefail
cd "$(dirname "$0")"
echo "===== 1/3 Bronze ====="; bash run_bronze.sh
echo "===== 2/3 Silver ====="; bash run_silver.sh
echo "===== 3/3 Gold staging ====="; bash run_gold.sh
