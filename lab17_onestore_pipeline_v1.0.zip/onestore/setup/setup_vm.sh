#!/usr/bin/env bash
# =====================================================================
# OneStore 데이터 파이프라인 실습 — VM 설치 스크립트
# 대상: Azure VM Standard_B4ms (4 vCPU / 16 GiB), Ubuntu Server 24.04 LTS
# 설치: Java 17 · Spark 3.5.9 · Kafka 4.3.1 (KRaft) · PostgreSQL 16 · JDBC 드라이버
# 실행: bash ~/onestore/setup/setup_vm.sh      (약 8~12분, 다시 실행해도 됨)
# =====================================================================
set -euo pipefail

SPARK_VER=3.5.9
KAFKA_VER=4.3.1
SCALA_KAFKA=2.13
LAB_HOME="$(cd "$(dirname "$0")/.." && pwd)"
DATA_DIR=/data
PG_PASSWORD="${PG_PASSWORD:-Onestore_2026}"
ME="$(id -un)"

log() { echo -e "\n\033[1;34m[setup] $*\033[0m"; }

download() {   # download <경로> <파일>: 현재 배포 미러 → 보관소 순서로 시도
  local path="$1" out="$2"
  [ -s "$out" ] && return 0
  curl -fL --retry 3 --connect-timeout 20 -o "$out" "https://dlcdn.apache.org/${path}" \
    || curl -fL --retry 3 --connect-timeout 20 -o "$out" "https://archive.apache.org/dist/${path}"
}

log "1/7 패키지 설치: Java 17, PostgreSQL 16, Python 3"
sudo apt-get update -y -q
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y -q \
     openjdk-17-jre-headless postgresql postgresql-contrib python3 curl unzip
sudo timedatectl set-timezone UTC          # OS 시간대는 UTC로 고정 (저장 기준)

log "2/7 Spark ${SPARK_VER} 내려받기"
mkdir -p "$HOME/downloads"; cd "$HOME/downloads"
download "spark/spark-${SPARK_VER}/spark-${SPARK_VER}-bin-hadoop3.tgz" spark.tgz
sudo tar -xzf spark.tgz -C /opt
sudo ln -sfn "/opt/spark-${SPARK_VER}-bin-hadoop3" /opt/spark

log "3/7 Kafka ${KAFKA_VER} 내려받기"
download "kafka/${KAFKA_VER}/kafka_${SCALA_KAFKA}-${KAFKA_VER}.tgz" kafka.tgz
sudo tar -xzf kafka.tgz -C /opt
sudo ln -sfn "/opt/kafka_${SCALA_KAFKA}-${KAFKA_VER}" /opt/kafka

sudo mkdir -p "$DATA_DIR"/{bronze,checkpoints,kafka-logs}
sudo chown -R "$ME:$ME" "$DATA_DIR" "/opt/spark-${SPARK_VER}-bin-hadoop3" "/opt/kafka_${SCALA_KAFKA}-${KAFKA_VER}"

log "4/7 환경 변수와 Spark 설정"
sudo tee /etc/profile.d/onestore.sh >/dev/null <<ENV
export SPARK_HOME=/opt/spark
export KAFKA_HOME=/opt/kafka
export PATH=\$PATH:/opt/spark/bin:/opt/kafka/bin
export PYSPARK_PYTHON=python3
export LAB_HOME=$LAB_HOME
ENV
grep -q 'profile.d/onestore.sh' "$HOME/.bashrc" || echo 'source /etc/profile.d/onestore.sh' >> "$HOME/.bashrc"
source /etc/profile.d/onestore.sh

cat > /opt/spark/conf/spark-defaults.conf <<CONF
spark.master                     local[4]
spark.driver.memory              3g
spark.sql.shuffle.partitions     8
spark.sql.session.timeZone       UTC
spark.driver.extraJavaOptions    -Duser.timezone=UTC
spark.ui.showConsoleProgress     false
spark.jars.packages              org.apache.spark:spark-sql-kafka-0-10_2.12:${SPARK_VER},org.postgresql:postgresql:42.7.14,com.microsoft.sqlserver:mssql-jdbc:12.10.2.jre11
CONF
sed 's/^rootLogger.level = .*/rootLogger.level = warn/' \
    /opt/spark/conf/log4j2.properties.template > /opt/spark/conf/log4j2.properties

log "5/7 Kafka (KRaft 단일 노드) 구성과 서비스 등록"
sed -i "s#^log.dirs=.*#log.dirs=${DATA_DIR}/kafka-logs#" /opt/kafka/config/server.properties
if [ ! -f "${DATA_DIR}/kafka-logs/meta.properties" ]; then
  CLUSTER_ID="$(/opt/kafka/bin/kafka-storage.sh random-uuid)"
  /opt/kafka/bin/kafka-storage.sh format --standalone -t "$CLUSTER_ID" -c /opt/kafka/config/server.properties
fi
sudo tee /etc/systemd/system/kafka.service >/dev/null <<UNIT
[Unit]
Description=Apache Kafka ${KAFKA_VER} (KRaft)
After=network.target

[Service]
User=${ME}
Environment="KAFKA_HEAP_OPTS=-Xmx1g -Xms1g"
ExecStart=/opt/kafka/bin/kafka-server-start.sh /opt/kafka/config/server.properties
ExecStop=/opt/kafka/bin/kafka-server-stop.sh
Restart=on-failure
LimitNOFILE=100000

[Install]
WantedBy=multi-user.target
UNIT
sudo systemctl daemon-reload
sudo systemctl enable --now kafka

log "6/7 PostgreSQL: 사용자·데이터베이스·메모리 설정"
sudo -u postgres psql -v ON_ERROR_STOP=1 -q <<SQL
DO \$\$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'onestore') THEN
    CREATE ROLE onestore LOGIN PASSWORD '${PG_PASSWORD}';
  END IF;
END \$\$;
SELECT 'CREATE DATABASE onestore OWNER onestore'
WHERE NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = 'onestore') \gexec
ALTER SYSTEM SET shared_buffers = '1GB';
ALTER SYSTEM SET work_mem = '16MB';
ALTER SYSTEM SET timezone = 'Asia/Seoul';
SQL
sudo systemctl restart postgresql

log "7/7 실습 설정 파일과 JDBC 드라이버 미리 받기"
mkdir -p "$LAB_HOME/config"
if [ ! -f "$LAB_HOME/config/pipeline.env" ]; then
  sed "s|^export PGPASSWORD=.*|export PGPASSWORD='${PG_PASSWORD}'|" \
      "$LAB_HOME/config/pipeline.env.example" > "$LAB_HOME/config/pipeline.env"
fi
chmod 600 "$LAB_HOME/config/pipeline.env"
# 첫 Spark 실행 때 받을 드라이버(약 10개 jar)를 지금 받아 둔다
spark-submit "$LAB_HOME/tools/warmup.py" 2>&1 | tail -n 3

log "완료. 새 터미널을 열거나  source ~/.bashrc  를 실행한 뒤  bash ~/onestore/setup/check_env.sh"
