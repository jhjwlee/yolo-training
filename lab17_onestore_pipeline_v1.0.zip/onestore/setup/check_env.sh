#!/usr/bin/env bash
# 설치 확인 — 모든 줄이 OK이면 다음 단계로
source /etc/profile.d/onestore.sh
source "$LAB_HOME/config/pipeline.env"
ok()   { printf "  %-28s \033[1;32mOK\033[0m  %s\n" "$1" "$2"; }
fail() { printf "  %-28s \033[1;31mFAIL\033[0m %s\n" "$1" "$2"; }
chk()  { local name="$1" detail; shift; if detail="$("$@" 2>&1)"; then ok "$name" "$(echo "$detail" | head -n1)"; else fail "$name" "$(echo "$detail" | tail -n1)"; fi; }

echo "[check] OneStore 실습 환경"
chk "Java"            bash -c "java -version 2>&1 | head -n1"
chk "Spark"           bash -c "spark-submit --version 2>&1 | grep -m1 -o 'version [0-9.]*'"
chk "Kafka 서비스"     systemctl is-active kafka
chk "Kafka 브로커 응답" bash -c "kafka-broker-api-versions.sh --bootstrap-server localhost:9092 >/dev/null && echo localhost:9092"
chk "PostgreSQL 서비스" systemctl is-active postgresql
chk "PostgreSQL 접속"  psql -tAc "SELECT 'onestore / ' || current_setting('TimeZone')"
chk "JDBC 드라이버"     bash -c "ls ~/.ivy2/jars 2>/dev/null | grep -E 'postgresql|mssql-jdbc|spark-sql-kafka' | wc -l | grep -qx 3 && echo 'postgresql, mssql-jdbc, spark-sql-kafka'"
chk "데이터 폴더"       bash -c "test -w /data/bronze && echo /data"
echo
free -h | head -n2
